$(function(){
    var $h2 = $('h2');
    console.log($h2);

    $('.details').html('$199.99');

    $h2.html('Sanlúcar de Barrameda');

    console.log($('#vacations'));
    
    console.log($('.america'));
});
