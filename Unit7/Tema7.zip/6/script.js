$(function () {
    // $(':button').masInfoClick();
    $(':button').masInfo();
});
